#include <stdio.h>
void world();

int main()
{
    fprintf(stdout, "Hello, ");
    world();
    return 0;
}
