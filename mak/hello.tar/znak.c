#include <stdio.h>
 
int znak()
{
    fprintf(stdout, "! \n");
    return 0;
}
