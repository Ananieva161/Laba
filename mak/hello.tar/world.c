#include <stdio.h>
void znak();

int world()
{
    fprintf(stdout, "world");
    znak();
    return 0;
}
